from flask import *
import database as db

app=Flask(__name__)

@app.route('/')
@app.route('/home')
def home():
    return render_template('home.html')

@app.route('/medicine',methods=['GET','POST'])
def medicine():
    mlist=db.selectall_medicine()
    return render_template('medicine.html',mlist=mlist)

@app.route('/deletemedicine/<int:mid>')
def deletebook(mid):
    db.delete_medicine(mid)
    return redirect(url_for('medicine'))

@app.route('/medicinedetail/<int:mid>')
def medicinedetail(mid):
    medlist=db.selectone_medicine(mid)
    mlist=list(medlist)
    return render_template('medicinedetail.html',mlist=mlist)

@app.route('/updatemedicine/<int:mid>',methods=["GET","POST"])
def updatemedicine(mid):
    if request.method=='GET':
        mlist = db.selectone_medicine(mid)
        return render_template("updatemedicine.html",mlist=mlist)
    elif request.method=='POST':
        name=request.form.get('name')
        color=request.form.get('color')
        type=request.form.get('type')
        dose=request.form.get('dosage')
        desc=request.form.get('desc')
        use=request.form.get('usage')
        ingr=request.form.get('ingredient')
        mfg=request.form.get('mfgdate')
        exp=request.form.get('expdate')
        price=request.form.get('price')
        comp=request.form.get('comp')
        db.update_medicine(mname=name,mcolor=color,mtype=type,mdose=dose,mdesc=desc,muse=use,mingr=ingr,mmfg=mfg,mexp=exp,mprice=price,mcomp=comp,mid=mid)
        return redirect(url_for('medicine'))

@app.route('/addmedicine',methods=["GET","POST"])
def addmedicine():
    if request.method=='GET':
        return render_template('addmedicine.html')
    
    elif request.method=='POST':
        name=request.form.get('name')
        color=request.form.get('color')
        type=request.form.get('type')
        dose=request.form.get('dosage')
        desc=request.form.get('desc')
        use=request.form.get('usage')
        ingr=request.form.get('ingredient')
        mfg=request.form.get('mfgdate')
        exp=request.form.get('expdate')
        price=request.form.get('price')
        comp=request.form.get('comp')
        db.insert_medicine(mname=name,mcolor=color,mtype=type,mdose=dose,mdesc=desc,muse=use,mingr=ingr,mmfg=mfg,mexp=exp,mprice=price,mcomp=comp)
        return redirect(url_for('medicine'))

@app.route('/stocks',methods=['GET','POST'])
def stocks():
    if request.method=='GET':
        return render_template('stocks.html')

if __name__==('__main__'):
    app.run(debug=True)