import pymysql as pm

con=pm.connect(host='localhost',user='root',password='Asif@123',database='medicalstore')

def insert_medicine(mname,mcolor,mtype,mdose,mdesc,muse,mingr,mmfg,mexp,mprice,mcomp):
    cursor=con.cursor()
    sql='insert into medicine(m_name,m_color,m_type,m_dose,m_desc,m_use,m_ingr,m_mfg,m_exp,m_price,m_comp) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)'
    i=cursor.execute(sql,(mname,mcolor,mtype,mdose,mdesc,muse,mingr,mmfg,mexp,mprice,mcomp))
    con.commit()
    return i

def update_medicine(mname,mcolor,mtype,mdose,mdesc,muse,mingr,mmfg,mexp,mprice,mcomp,mid):
    cursor=con.cursor()
    sql='update medicine set m_name=%s,m_color=%s,m_type=%s,m_dose=%s,m_desc=%s,m_use=%s,m_ingr=%s,m_mfg=%s,m_exp=%s,m_price=%s,m_comp=%swhere m_id=%s'
    i=cursor.execute(sql,(mname,mcolor,mtype,mdose,mdesc,muse,mingr,mmfg,mexp,mprice,mcomp,mid))
    con.commit()
    return i

def delete_medicine(mid):
    cursor=con.cursor()
    sql='delete from medicine where m_id=%s'
    i=cursor.execute(sql,(mid))
    con.commit()
    return i

def selectall_medicine():
    cursor=con.cursor()
    sql='select * from medicine'
    cursor.execute(sql)
    rows=cursor.fetchall()
    return rows

def selectone_medicine(mid):
    cursor=con.cursor()
    sql='select * from medicine where m_id=%s'
    cursor.execute(sql,(mid))
    row=cursor.fetchone()
    return row

